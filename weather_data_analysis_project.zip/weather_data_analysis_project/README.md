# Weather Data Analysis

## Project Overview
A complete Python weather-data analysis project covering load, cleaning, validation, analysis, visualization, insights and testing.

## Objectives
- Analyze temperature, rainfall, humidity, wind, pressure, UV and visibility.
- Compare seasons and weather conditions.
- Produce 6 chart types.
- Demonstrate validation and error handling.

## Setup
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Create an environment: `python -m venv .venv`.
4. Activate: Windows `.venv\Scripts\activate`; macOS/Linux `source .venv/bin/activate`.
5. Install: `pip install -r requirements.txt`.
6. Run: `python main.py`.
7. Test: `pytest -q`.

## Structure
```text
weather_data_analysis_project/
├── data/
│   ├── weather_data_analysis.csv
│   └── weather_cleaned.csv
├── visualizations/
├── report/PROJECT_REPORT.md
├── tests/test_analysis.py
├── main.py
├── requirements.txt
└── README.md
```

## Technical Details
The architecture is **Load → Clean → Validate → Analyze → Visualize → Report**. Pandas DataFrames provide tabular processing; Matplotlib creates static charts. Feature engineering adds temperature range, rainy-day flag and month name. Aggregations use group-by operations for seasonal and monthly summaries.

## Validation and Error Handling
The executable checks file existence, required columns, date parsing, numeric conversion, missing values, duplicate rows, humidity/rainfall/wind/UV/visibility ranges and `Min Temperature ≤ Temperature ≤ Max Temperature`. Invalid input produces a descriptive error and non-zero exit status.

## Visual Documentation
The `visualizations/` folder contains six analytical charts plus `00_pipeline_architecture.png`, which can be used as evidence of the analysis workflow.

## Testing Evidence
Run `pytest -q`. Tests cover dataset existence, schema/quality constraints and chart generation.

## Submission Checklist
- [x] Project overview
- [x] Setup instructions
- [x] Organized code structure
- [x] Visual documentation
- [x] Technical details
- [x] Error handling and validation
- [x] Testing evidence
- [x] Written insights
- [x] 6 chart types
