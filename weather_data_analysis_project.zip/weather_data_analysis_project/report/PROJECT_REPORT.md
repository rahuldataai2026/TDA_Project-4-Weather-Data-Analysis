# Weather Data Analysis — Project Report

## Project Overview
This project analyzes **1,826 daily weather records** from **01 Jan 2021 to 31 Dec 2025**. The goal is to demonstrate a complete, reproducible data-analysis pipeline: loading, cleaning, validation, exploratory analysis, visualization and reporting.

## Key Insights
- Average temperature: **24.04 °C**.
- Highest daily average temperature: **34.7 °C (29 Jul 2021)**.
- Lowest daily average temperature: **14.6 °C (22 Dec 2025)**.
- Highest daily rainfall: **62.3 mm (13 Nov 2022)**.
- Most frequent weather condition: **Sunny (1,480 days)**.
- Temperature–humidity Pearson correlation: **-0.47**; this indicates association, not causation.
- Data quality: **0 missing values and 0 duplicate rows**; all range and temperature-order checks passed.

## Seasonal Summary
| Season | Avg Temp °C | Avg Humidity % | Rainfall mm | Avg Wind km/h | Avg UV | Visibility km |
|---|---:|---:|---:|---:|---:|---:|
| Winter | 18.37 | 65.57 | 656.7 | 8.15 | 3.55 | 9.78 |
| Spring | nan | nan | nan | nan | nan | nan |
| Summer | 26.71 | 59.85 | 558.0 | 7.98 | 7.16 | 9.90 |
| Monsoon | 28.40 | 58.56 | 2412.0 | 8.28 | 7.87 | 9.62 |
| Autumn | nan | nan | nan | nan | nan | nan |

## Charts and Interpretation
1. **Line chart:** reveals the annual temperature cycle.
2. **Bar chart:** compares accumulated rainfall by season.
3. **Histogram:** shows the distribution and concentration of daily temperatures.
4. **Scatter plot:** evaluates the temperature–humidity relationship.
5. **Box plot:** compares seasonal temperature spread and potential outliers.
6. **Frequency bar chart:** identifies the dominant weather categories.

## Conclusion
The dataset shows strong seasonal structure and useful relationships among atmospheric variables. The six complementary visualizations provide trend, comparison, distribution, relationship and categorical perspectives, satisfying the requested analytical coverage.
