from pathlib import Path
import pandas as pd
BASE=Path(__file__).resolve().parents[1]
def test_dataset_exists(): assert (BASE/"data/weather_data_analysis.csv").exists()
def test_data_quality():
 df=pd.read_csv(BASE/"data/weather_data_analysis.csv"); assert df.shape==(1826,14); assert df.isna().sum().sum()==0; assert df.duplicated().sum()==0; assert df["Humidity_%"].between(0,100).all(); assert (df["Rainfall_mm"]>=0).all(); assert (df["Min_Temperature_C"]<=df["Temperature_C"]).all(); assert (df["Temperature_C"]<=df["Max_Temperature_C"]).all()
def test_visualizations(): assert len(list((BASE/"visualizations").glob("*.png")))>=6
