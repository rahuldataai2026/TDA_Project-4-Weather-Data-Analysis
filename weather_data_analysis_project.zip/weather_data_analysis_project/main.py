from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
DATA = BASE / "data" / "weather_data_analysis.csv"
OUT = BASE / "visualizations"
EXPECTED = ["Date","Year","Month","Season","Temperature_C","Max_Temperature_C","Min_Temperature_C","Humidity_%","Rainfall_mm","Wind_Speed_kmh","Atmospheric_Pressure_hPa","UV_Index","Visibility_km","Weather"]
NUMERIC = ["Temperature_C","Max_Temperature_C","Min_Temperature_C","Humidity_%","Rainfall_mm","Wind_Speed_kmh","Atmospheric_Pressure_hPa","UV_Index","Visibility_km"]

def load_data(path=DATA):
    if not path.exists(): raise FileNotFoundError(f"Dataset not found: {path}")
    return pd.read_csv(path)

def clean_validate(df):
    missing=[c for c in EXPECTED if c not in df.columns]
    if missing: raise ValueError(f"Missing required columns: {missing}")
    df=df.copy(); df["Date"]=pd.to_datetime(df["Date"],format="%d-%m-%Y",errors="coerce")
    if df["Date"].isna().any(): raise ValueError("Invalid date values found")
    for c in NUMERIC: df[c]=pd.to_numeric(df[c],errors="coerce")
    if df[NUMERIC].isna().any().any(): raise ValueError("Missing or non-numeric values found")
    if df.duplicated().any(): raise ValueError("Duplicate rows detected")
    if not df["Humidity_%"].between(0,100).all(): raise ValueError("Humidity outside 0–100%")
    if not (df["Rainfall_mm"]>=0).all(): raise ValueError("Negative rainfall detected")
    if not (df["Wind_Speed_kmh"]>=0).all(): raise ValueError("Negative wind speed detected")
    if not df["UV_Index"].between(0,20).all(): raise ValueError("UV index outside expected range")
    if not df["Visibility_km"].ge(0).all(): raise ValueError("Negative visibility detected")
    if not ((df["Min_Temperature_C"]<=df["Temperature_C"]) & (df["Temperature_C"]<=df["Max_Temperature_C"])).all(): raise ValueError("Temperature ordering constraint failed")
    df["Temperature_Range_C"]=df.Max_Temperature_C-df.Min_Temperature_C; df["Rainy_Day"]=df.Rainfall_mm>0; df["Month_Name"]=df.Date.dt.strftime("%b")
    return df

def analyze(df):
    seasonal=df.groupby("Season").agg(Avg_Temperature_C=("Temperature_C","mean"),Total_Rainfall_mm=("Rainfall_mm","sum"),Avg_Humidity_pct=("Humidity_%","mean"))
    monthly=df.groupby(df.Date.dt.month).agg(Avg_Temperature_C=("Temperature_C","mean"),Total_Rainfall_mm=("Rainfall_mm","sum"))
    return seasonal,monthly

def visualize(df):
    OUT.mkdir(exist_ok=True)
    m=df.groupby(df.Date.dt.month).Temperature_C.mean(); fig,ax=plt.subplots(); ax.plot(m.index,m.values,marker="o"); ax.set(title="Average Temperature by Month",xlabel="Month",ylabel="Temperature (°C)"); fig.tight_layout(); fig.savefig(OUT/"01_temperature_trend.png",dpi=180); plt.close(fig)
    s=df.groupby("Season").Rainfall_mm.sum(); fig,ax=plt.subplots(); ax.bar(s.index,s.values); ax.set(title="Total Rainfall by Season",ylabel="Rainfall (mm)"); fig.tight_layout(); fig.savefig(OUT/"02_seasonal_rainfall.png",dpi=180); plt.close(fig)
    fig,ax=plt.subplots(); ax.hist(df.Temperature_C,bins=25,edgecolor="black"); ax.set(title="Temperature Distribution",xlabel="Temperature (°C)",ylabel="Days"); fig.tight_layout(); fig.savefig(OUT/"03_temperature_distribution.png",dpi=180); plt.close(fig)
    fig,ax=plt.subplots(); ax.scatter(df["Humidity_%"],df.Temperature_C,alpha=.45,s=18); ax.set(title="Humidity vs Temperature",xlabel="Humidity (%)",ylabel="Temperature (°C)"); fig.tight_layout(); fig.savefig(OUT/"04_humidity_temperature_scatter.png",dpi=180); plt.close(fig)
    order=["Winter","Spring","Summer","Monsoon","Autumn"]; fig,ax=plt.subplots(); ax.boxplot([df.loc[df.Season==s,"Temperature_C"] for s in order],labels=order); ax.set(title="Temperature Variation by Season",ylabel="Temperature (°C)"); fig.tight_layout(); fig.savefig(OUT/"05_seasonal_temperature_boxplot.png",dpi=180); plt.close(fig)
    w=df.Weather.value_counts(); fig,ax=plt.subplots(); ax.bar(w.index,w.values); ax.set(title="Weather Condition Frequency",ylabel="Number of Days"); fig.tight_layout(); fig.savefig(OUT/"06_weather_frequency.png",dpi=180); plt.close(fig)

def main():
    try:
        df=clean_validate(load_data()); df.to_csv(BASE/"data"/"weather_cleaned.csv",index=False); analyze(df); visualize(df)
        print(f"Analysis completed: {len(df):,} rows processed.")
        print(f"Average temperature: {df.Temperature_C.mean():.2f} °C")
        print(f"Temperature/humidity correlation: {df.Temperature_C.corr(df['Humidity_%']):.2f}")
    except (FileNotFoundError,ValueError,pd.errors.ParserError) as exc:
        print(f"ERROR: {exc}"); raise SystemExit(1)

if __name__=="__main__": main()
